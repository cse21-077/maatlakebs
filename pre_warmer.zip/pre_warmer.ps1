# pre_warmer.ps1
# MaatlaKebs — MT5 Terminal Pre-Warmer (EA Slave Architecture)
# ============================================================
# Launches ONLY active/assigned MT5 terminals.
# Copies Slave EA to each terminal.
# DOES NOT launch empty/unassigned slots.
#
# USAGE:
#   .\pre_warmer.ps1
#
# REQUIREMENTS:
#   - PowerShell 5.1+
#   - Supabase service key in $env:SUPABASE_SERVICE_KEY
#   - Slave EA compiled at C:\MaatlaKebs\MaatlaKebs_Slave_v2.ex5
# ============================================================

param(
    [string]$SupabaseUrl = "https://yrnjemftbqwvbvknlxol.supabase.co",
    [string]$SupabaseKey = $env:SUPABASE_SERVICE_KEY,
    [string]$EaSource = "C:\MaatlaKebs\MaatlaKebs_Slave_v2.ex5",
    [string]$SignalFolder = "C:\MaatlaKebs\signals",
    [string]$ResultFolder = "C:\MaatlaKebs\results",
    [int]$LaunchDelaySec = 3
)

# ── Validation ────────────────────────────────────────────────

if (-not $SupabaseKey) {
    Write-Error "SUPABASE_SERVICE_KEY not set. Set it as environment variable or pass -SupabaseKey"
    exit 1
}

if (-not (Test-Path $EaSource)) {
    Write-Error "Slave EA not found at: $EaSource. Compile it in MetaEditor first (F7)."
    exit 1
}

# ── Create directories ────────────────────────────────────────

New-Item -ItemType Directory -Path $SignalFolder -Force | Out-Null
New-Item -ItemType Directory -Path $ResultFolder -Force | Out-Null
Write-Host "Signal/Result folders ready." -ForegroundColor Green

# ── Fetch active students from Supabase ───────────────────────

$headers = @{
    "apikey"        = $SupabaseKey
    "Authorization" = "Bearer $SupabaseKey"
}

$url = "$SupabaseUrl/rest/v1/student_accounts?is_active=eq.true&folder_path=not.is.null&select=folder_path,mt5_login,user_id"

try {
    $response = Invoke-RestMethod -Uri $url -Headers $headers -Method Get -ErrorAction Stop
} catch {
    Write-Error "Failed to fetch students from Supabase: $_"
    exit 1
}

if (-not $response) {
    Write-Error "No active students with folder_path found in Supabase."
    exit 1
}

# Extract unique folder paths
$folders = $response | ForEach-Object { $_.folder_path } | Select-Object -Unique
Write-Host "Found $($folders.Count) active terminal folder(s)." -ForegroundColor Cyan

# ── Kill existing terminals ───────────────────────────────────

Write-Host "Stopping existing terminal64.exe processes..." -ForegroundColor Yellow
Get-Process -Name "terminal64" -ErrorAction SilentlyContinue | Stop-Process -Force -ErrorAction SilentlyContinue
Start-Sleep -Seconds 3

# ── Copy EA and launch each terminal ──────────────────────────

$launched = 0
$failed = 0

foreach ($folder in $folders) {
    $terminalPath = Join-Path $folder "terminal64.exe"
    $expertsPath = Join-Path $folder "MQL5\Experts"
    $slaveEaPath = Join-Path $expertsPath "MaatlaKebs_Slave_v2.ex5"

    if (-not (Test-Path $terminalPath)) {
        Write-Warning "terminal64.exe not found in: $folder — skipping"
        $failed++
        continue
    }

    # Copy Slave EA
    try {
        New-Item -ItemType Directory -Path $expertsPath -Force | Out-Null
        Copy-Item -Path $EaSource -Destination $slaveEaPath -Force -ErrorAction Stop
        Write-Host "  [OK] EA copied to $slaveEaPath" -ForegroundColor DarkGray
    } catch {
        Write-Warning "Failed to copy EA to $folder : $_"
    }

    # Launch terminal with portable mode
    try {
        Start-Process -FilePath $terminalPath -ArgumentList "/portable" -WorkingDirectory $folder -WindowStyle Normal
        Write-Host "  [LAUNCHED] $folder" -ForegroundColor Green
        $launched++
    } catch {
        Write-Error "Failed to launch $folder : $_"
        $failed++
        continue
    }

    # Stagger launches to avoid Windows resource contention
    if ($LaunchDelaySec -gt 0) {
        Start-Sleep -Seconds $LaunchDelaySec
    }
}

# ── Summary ───────────────────────────────────────────────────

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  PRE-WARMER COMPLETE" -ForegroundColor Cyan
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Launched:  $launched terminals" -ForegroundColor Green
Write-Host "  Failed:    $failed terminals" -ForegroundColor $(if ($failed -gt 0) { "Red" } else { "Green" })
Write-Host "  EA copied: $launched terminals" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "NEXT STEPS:" -ForegroundColor Yellow
Write-Host "  1. Wait 30-60 seconds for all terminals to fully load" -ForegroundColor White
Write-Host "  2. Open a chart in EACH terminal (e.g., Volatility 75 Index)" -ForegroundColor White
Write-Host "  3. Attach MaatlaKebs_Slave_v2 EA to each chart" -ForegroundColor White
Write-Host "  4. Verify: Experts tab shows '[MaKebs] Slave EA v2.0 — INITIALIZED'" -ForegroundColor White
Write-Host "  5. Start mt5_manager.py" -ForegroundColor White
Write-Host ""
